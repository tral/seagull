seagull
=======

Tiny tool for performing special USSD requests

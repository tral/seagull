/** Automatically generated file. DO NOT MODIFY */
package ru.perm.trubnikov.seagull;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}